# One page Portfolio Website (HTML CSS Project for Ppractice)
## Watch The Complete Tutorial ![YouTube Video Views](https://img.shields.io/youtube/views/ZFQkb26UD1Y?style=social) : https://youtu.be/ZFQkb26UD1Y   


This project is for html &amp; css practice. We made this for youtube tutorial purpose.
<b>coded by [Shaif Arfan](https://github.com/shaifarfan)</b>
### 👍 HAVE FUN 👍
Thanks, Arfan

![Watch Now](./img/Design.jpg)
